<?php

require_once '_classes/DB.php';

$db = new DB(DATABASE_HOST,DATABASE_NAME,DATABASE_USER, DATABASE_PASSWORD);

$db->setFetchMode(PDO::FETCH_ASSOC);

$options = array(
    PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8',
);
//error_reporting(0);
$db1 = new PDO('mysql:host=localhost;dbname=suivi_des_requisitions2', 'root','');