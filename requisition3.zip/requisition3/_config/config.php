<?php

// --------------------------- //
//       ERRORS DISPLAY        //
// --------------------------- //

//!\\ A enlever lors du déploiement
 error_reporting(E_ERROR | E_PARSE);
 ini_set('display_errors', true);


// --------------------------- //
//          SESSIONS           //
// --------------------------- //

ini_set('session.cookie_lifetime', false);
session_start();


// --------------------------- //
//         CONSTANTS           //
// --------------------------- //

// Paths
define("PATH_REQUIRE", substr($_SERVER['SCRIPT_FILENAME'], 0, -9)); // Pour fonctions d'inclusion php
define("PATH", substr($_SERVER['PHP_SELF'], 0, -9)); // Pour images, fichiers etc (html)

// Website informations
define("WEBSITE_TITLE", "Mon site");
define("WEBSITE_NAME", "Mon site");
define("WEBSITE_URL", "https://monsite.com");
define("WEBSITE_DESCRIPTION", "Description du site");
define("WEBSITE_KEYWORDS", "");
define("WEBSITE_LANGUAGE", "");
define("WEBSITE_AUTHOR", "");
define("WEBSITE_AUTHOR_MAIL", "");

// Facebook Open Graph tags
define("WEBSITE_FACEBOOK_NAME", "");
define("WEBSITE_FACEBOOK_DESCRIPTION", "");
define("WEBSITE_FACEBOOK_URL", "");
define("WEBSITE_FACEBOOK_IMAGE", "");


// DataBase informations
define("DATABASE_HOST", "localhost");
define("DATABASE_NAME", "suivi_des_requisitions2");
define("DATABASE_USER", "root");
define("DATABASE_PASSWORD", "");

// Données pour  les services
define("REEVAL", "REEVALUATION");
define("CONTS", "AGENT CONTESTATION");
define("AUDI", "AUDITEUR");
define("INS", "INSPECTION");
define("OFFVISIT", "OFFICIER VISITE");
define("OPEVISIT", "OPERATEUR VISITE");
define("AGCOURRIER", "AGENT COURRIER");

//Background color

define("BGCOLOR", "background-color:#e3f0fe ;");

//Données pour historique
define("VISIT", "Enregistrement de visite par  ".$_SESSION['nom_user']." ".$_SESSION['prenom_user']."");
define("MODIFVISIT", "Modification d' un enregistrement de visite par ".$_SESSION['nom_user']." ".$_SESSION['prenom_user']." ");
define("REVAL", "Enregistrement de reevaluation par ".$_SESSION['nom_user']." ".$_SESSION['prenom_user']."");
define("MODIFREEVAL", "Modification d'un enregistrement de reevaluation par ".$_SESSION['nom_user']." ".$_SESSION['prenom_user']."");
define("COURRIER", "Enregistrement de courrier par ".$_SESSION['nom_user']." ".$_SESSION['prenom_user']."");
define("MODIFCOURRIER", "Modification d'enregistrement de courrier par ".$_SESSION['nom_user']." ".$_SESSION['prenom_user']."");
define("CONTEST", "Enregistrement de contestation par ".$_SESSION['nom_user']." ".$_SESSION['prenom_user']."");
define("MODIFCONTEST", "Modification de contestation par ".$_SESSION['nom_user']." ".$_SESSION['prenom_user']."");

//Langues
define("DEFAULT_LANGUAGE", "fr");

