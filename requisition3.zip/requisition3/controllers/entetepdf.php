<table style="font-size: 20px;" style="width: 100%;" >
    <tr>
        <td style="width: 20%;" >
            <img src="https://www.douanes.ci/sites/all/themes/douane_theme/assets/images/logo.png"  align="left" hspace="12" width="60" height="78" border="0"/>

        </td>
        <td style="width: 80%; text-align: center; ">
                MINISTERE DU BUDGET ET DU PORTEFEUILLE DE L'ETAT <br/><br/>
                <span style="font: bold; color:green;">DIRECTION GENERAL DES DOUANES</span> 
        </td>
        
    </tr>

</table>
<hr>