<?php

session_start();

if (!empty($_POST) && isset($_POST['login'])) {
    $username = $_POST['matricule'];
    $password = $_POST['password'];

    if(isset($username) && isset($password)) {


        if (!empty($username) && !empty($password))
        {
            
            $user = utilisateur::login($username,$password); 
            $_SESSION['iduser']= $user['iduser']; 
            $_SESSION['username']= $user['login_user'];
            
            $_SESSION['password_user']= $user['password_user'];
            $_SESSION['civilite_user']= $user['civilite_user'];
            $_SESSION['nom_user']= $user['nom_user'];
            $_SESSION['photo_user']= $user['photo_user'];
            $_SESSION['prenom_user']= $user['prenom_user'];
            $_SESSION['email_user']= $user['email_user'];
                       

            $pwduser = sha1($password);
           // echo $username.'-'.$pwduser.'--'.$user['login_user'].'--@'.$user['password_user']; exit();
            if(isset($user) && $user['login_user']==$username && $user['password_user']==$pwduser){
               // if($user['login_user']=='dev'){ $_SESSION['profil']=2;} else { $_SESSION['profil']=1; }
                $_SESSION['profil']=profiluser($user['login_user']);


            //    echo '@..'.$_SESSION['profil'].'--'.$user['login_user'];
            //     exit();
                $_SESSION['no_cnx']=0;
                redirect('liste_tc');
            }               
            else{
                $message = '<div class="col-md-12 alert alert-info" style="background: #a1c1e7;">
                            <button class="close" data-dismiss="alert"><i class="pci-cross pci-circle"></i></button>
                             <strong>Oups !! </strong>login ou mot de passe incorrect   
                            </div>'; 
                $_SESSION['no_cnx']+=1;
                if($_SESSION['no_cnx']>3){ $no_cnx = '<div class="col-md-12 alert alert-danger" >
                    <button class="close" data-dismiss="alert"><i class="pci-cross pci-circle"></i></button>
                     Contacter un administrateur, votre compte risque d\'etre suspendu   
                    </div>';   }
            }
        }
    }
}





?>