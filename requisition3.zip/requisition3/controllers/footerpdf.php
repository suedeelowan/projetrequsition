<hr>
<table style="font-size: 12px; font-style: normal; width: 100%; ">
<tr style="vertical-align: top;">
    <td style="width: 40%;" >
       <span>Direction de l’Analyse des Risques,du Renseignement et de la Valeur </span> <br/>
        VRIDI <br/>
        BP: V 25 Abidjan <br/>



    </td>
    <td style="width: 30%;  " >
            Email : <b>darrv.petition@douanes.ci</b>
    </td>
    <td style="width: 20%;" >
        Tél : 21 22 17 00/ 21 22 17 25<br/>
        Poste : 1849 <br>
                1852 <br>
                1862  <br>

    </td>
</tr>

</table>