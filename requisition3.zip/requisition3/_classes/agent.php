<?php

class agent
{
    public $ID;
    public $ID_AG;
    public $NOM_AG;
    public $MATRICULE_AG;
    public $SERVICE_AG;

    function __construct($id) {

            global $db;

            $id = str_secur($id);

            $reqSelPays = $db->fetch('SELECT * FROM agent WHERE ID = ?', [$id], false);
            $datareqSelPays = $reqSelPays;

                $this->ID = $id;
                $this->ID_AG= $id['ID_AG'];
                $this->NOM_AG= $datareqSelPays['NOM_AG'];
                $this->MATRICULE_AG= $datareqSelPays['MATRICULE_AG'];
                $this->SERVICE_AG= $datareqSelPays['SERVICE_AG'];


    }


//Liste de tous les users
static function getAllService($service) {

    global $db;

    $requtilisateur = $db->fetch('SELECT * FROM  agent WHERE SERVICE_AG=? ORDER BY NOM_AG ASC ', [$service], true);
    return $requtilisateur;

}




}